# S3 to Oracle Loader

A metadata-driven loader with per-job logging and S3 archival.
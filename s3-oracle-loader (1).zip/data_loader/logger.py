# Logger utility for the framework

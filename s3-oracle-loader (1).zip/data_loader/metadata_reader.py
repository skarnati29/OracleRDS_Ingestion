# Reads job metadata from DB

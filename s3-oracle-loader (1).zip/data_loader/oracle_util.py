# Oracle DB connection utils

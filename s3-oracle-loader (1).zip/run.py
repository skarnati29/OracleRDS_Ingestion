# Entry point for loading jobs

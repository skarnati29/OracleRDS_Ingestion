# S3 to Oracle Loader

Metadata-driven framework to load files from S3 to Oracle RDS using SQL*Loader.
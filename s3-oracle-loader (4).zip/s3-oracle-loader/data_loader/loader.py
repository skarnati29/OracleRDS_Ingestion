from data_loader.logger import setup_logger
from data_loader.s3_downloader import download_file_from_s3, move_s3_file_to_archive
from data_loader.oracle_util import execute_sql
from data_loader.sqlldr_runner import run_sqlldr
from datetime import datetime

def run_job(job):
    logger = setup_logger(job['job_name'])
    try:
        logger.info(f"🚀 Starting job: {job['job_name']}")
        local_file_path = download_file_from_s3(job['s3_bucket'], job['s3_key'])
        logger.info(f"File downloaded to {local_file_path}")

        if job.get("pre_sql"):
            execute_sql(job["pre_sql"])
            logger.info("Pre-SQL executed")

        run_sqlldr(local_file_path, job["target_table"], job["column_mapping"])
        logger.info("Data loaded using SQL*Loader")

        if job.get("post_sql"):
            execute_sql(job["post_sql"])
            logger.info("Post-SQL executed")

        archive_key = move_s3_file_to_archive(job["s3_bucket"], job["s3_key"])
        logger.info(f"✅ Archived file to s3://{job['s3_bucket']}/{archive_key}")
        logger.info(f"✅ Job completed: {job['job_name']}")

    except Exception as e:
        logger.exception(f"❌ Job failed: {job['job_name']} - {str(e)}")

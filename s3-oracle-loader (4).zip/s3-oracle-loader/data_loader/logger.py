import os
import logging
from datetime import datetime

def setup_logger(job_name=None):
    os.makedirs("logs", exist_ok=True)
    log_file = f"logs/{job_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log" if job_name else "logs/loader.log"
    logger = logging.getLogger(job_name or "global")
    logger.setLevel(logging.INFO)
    if not logger.handlers:
        handler = logging.FileHandler(log_file)
        formatter = logging.Formatter('%(asctime)s [%(levelname)s] %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    return logger

import cx_Oracle
import os
import json

def get_job_from_metadata(job_name):
    conn = cx_Oracle.connect(os.getenv("ORACLE_USER"), os.getenv("ORACLE_PASS"), os.getenv("ORACLE_DSN"))
    cursor = conn.cursor()
    cursor.execute("""
        SELECT job_name, s3_bucket, s3_key, target_table, column_mapping_json, pre_sql, post_sql, load_type
        FROM job_metadata
        WHERE job_name = :1 AND enabled = 'Y'
    """, [job_name])
    row = cursor.fetchone()
    cursor.close()
    conn.close()
    if row:
        return {
            "job_name": row[0],
            "s3_bucket": row[1],
            "s3_key": row[2],
            "target_table": row[3],
            "column_mapping": json.loads(row[4]),
            "pre_sql": row[5],
            "post_sql": row[6],
            "load_type": row[7]
        }
    return None

import cx_Oracle
import os

def execute_sql(sql):
    conn = cx_Oracle.connect(os.getenv("ORACLE_USER"), os.getenv("ORACLE_PASS"), os.getenv("ORACLE_DSN"))
    cursor = conn.cursor()
    cursor.execute(sql)
    conn.commit()
    cursor.close()
    conn.close()

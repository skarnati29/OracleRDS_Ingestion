import boto3
import os
from datetime import datetime

def download_file_from_s3(bucket, key):
    local_path = os.path.join("/tmp/data_loader", os.path.basename(key))
    os.makedirs(os.path.dirname(local_path), exist_ok=True)
    s3 = boto3.client('s3')
    s3.download_file(bucket, key, local_path)
    return local_path

def move_s3_file_to_archive(bucket, source_key, archive_prefix="archive/"):
    s3 = boto3.client('s3')
    filename = os.path.basename(source_key)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    archive_key = f"{archive_prefix}{filename.rsplit('.', 1)[0]}_{timestamp}.{filename.rsplit('.', 1)[-1]}"
    s3.copy_object(CopySource={'Bucket': bucket, 'Key': source_key}, Bucket=bucket, Key=archive_key)
    s3.delete_object(Bucket=bucket, Key=source_key)
    return archive_key

import subprocess

def run_sqlldr(data_file_path, table_name, column_mapping):
    control_file = f"/tmp/{table_name}.ctl"
    with open(control_file, "w") as f:
        f.write(f"""LOAD DATA
INFILE '{data_file_path}'
INTO TABLE {table_name}
APPEND
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
TRAILING NULLCOLS
({', '.join(column_mapping.values())})
""")
    log_file = control_file.replace('.ctl', '.log')
    subprocess.run([
        "sqlldr",
        f"{os.getenv('ORACLE_USER')}/{os.getenv('ORACLE_PASS')}@{os.getenv('ORACLE_DSN')}",
        f"control={control_file}",
        f"log={log_file}"
    ], check=True)

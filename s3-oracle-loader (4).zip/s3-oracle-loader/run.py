import os
import argparse
from data_loader.loader import run_job
from data_loader.metadata_reader import get_job_from_metadata

def main():
    parser = argparse.ArgumentParser(description="Run S3 to Oracle load job.")
    parser.add_argument("--job-name", required=True, help="Job name to execute (from metadata table)")
    args = parser.parse_args()
    job = get_job_from_metadata(args.job_name)
    if job:
        run_job(job)
    else:
        print(f"❌ Job '{args.job_name}' not found or not enabled.")

if __name__ == "__main__":
    main()

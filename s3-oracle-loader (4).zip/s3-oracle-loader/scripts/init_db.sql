CREATE TABLE job_metadata (
    job_name VARCHAR2(100),
    s3_bucket VARCHAR2(200),
    s3_key VARCHAR2(500),
    target_table VARCHAR2(100),
    column_mapping_json CLOB,
    pre_sql CLOB,
    post_sql CLOB,
    load_type VARCHAR2(20),
    enabled CHAR(1)
);

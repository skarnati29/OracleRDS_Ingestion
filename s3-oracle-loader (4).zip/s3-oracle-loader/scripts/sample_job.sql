INSERT INTO job_metadata (
    job_name, s3_bucket, s3_key, target_table,
    column_mapping_json, pre_sql, post_sql, load_type, enabled
) VALUES (
    'load_customers', 'my-bucket', 'data/customers.csv', 'customers',
    '{"customer_id": "customer_id", "name": "name"}',
    'DELETE FROM customers_stage',
    'MERGE INTO customers USING customers_stage ON (...)',
    'replace', 'Y'
);

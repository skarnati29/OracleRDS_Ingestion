# S3 → Oracle Loader (Metadata-Driven)

Loads timestamp-appended files from S3 into Oracle via SQL*Loader, with metadata stored in Oracle.

## Quick Start
1. Create table and sample job:
   ```sql
   @scripts/init_db.sql
   @scripts/sample_job.sql
   ```
2. Set env vars (or copy `.env.example` to `.env`).
3. Install deps:
   ```bash
   pip install -r requirements.txt
   ```
4. Run one job:
   ```bash
   ./run_job.sh load_customers
   ```

## How files are resolved
- If `s3_key` is set, that exact object is loaded.
- Else the loader finds the latest object under `s3_key_prefix`, optionally filtered by `filename_regex`.
- After a successful load, the exact source key is moved to `archive_prefix` keeping its timestamped filename.

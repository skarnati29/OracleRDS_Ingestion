from data_loader.logger import setup_logger
from data_loader.s3_downloader import resolve_source_key, download_file_from_s3, move_s3_file_to_archive
from data_loader.oracle_util import execute_sql
from data_loader.sqlldr_runner import run_sqlldr

def run_job(job):
    log = setup_logger(job["job_name"])
    try:
        log.info(f"🚀 Starting job: {job['job_name']}")

        source_key = resolve_source_key(job)
        log.info(f"Resolved source key: s3://{job['s3_bucket']}/{source_key}")

        local_file = download_file_from_s3(job["s3_bucket"], source_key)
        log.info(f"Downloaded to: {local_file}")

        if job.get("pre_sql"):
            execute_sql(job["pre_sql"])
            log.info("Pre-SQL executed")

        run_sqlldr(local_file, job["target_table"], job["column_mapping"])
        log.info("Data loaded via SQL*Loader")

        if job.get("post_sql"):
            execute_sql(job["post_sql"])
            log.info("Post-SQL executed")

        archive_key = move_s3_file_to_archive(job["s3_bucket"], source_key, job.get("archive_prefix"))
        log.info(f"✅ Archived: s3://{job['s3_bucket']}/{archive_key}")

        log.info(f"✅ Job completed: {job['job_name']}")
    except Exception as e:
        log.exception(f"❌ Job failed: {job['job_name']} - {e}")
        raise

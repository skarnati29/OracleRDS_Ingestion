import os
import logging
from datetime import datetime

def setup_logger(job_name=None):
    os.makedirs("logs", exist_ok=True)
    log_file = f"logs/{job_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log" if job_name else "logs/loader.log"
    logger = logging.getLogger(job_name or "global")
    logger.setLevel(logging.INFO)
    if not any(isinstance(h, logging.FileHandler) and getattr(h, 'baseFilename', '').endswith(log_file) for h in logger.handlers):
        fh = logging.FileHandler(log_file)
        fh.setFormatter(logging.Formatter('%(asctime)s [%(levelname)s] %(message)s'))
        logger.addHandler(fh)
    return logger

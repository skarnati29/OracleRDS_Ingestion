import cx_Oracle
import os
import json
from typing import Optional, Dict, Any

def get_job_from_metadata(job_name: str) -> Optional[Dict[str, Any]]:
    conn = cx_Oracle.connect(os.getenv("ORACLE_USER"), os.getenv("ORACLE_PASS"), os.getenv("ORACLE_DSN"))
    cur = conn.cursor()
    cur.execute("""
        SELECT job_name, s3_bucket, s3_key, s3_key_prefix, filename_regex, archive_prefix,
               file_format, target_table, column_mapping_json, pre_sql, post_sql, load_type
          FROM job_metadata
         WHERE job_name = :1 AND enabled = 'Y'
    """, [job_name])
    row = cur.fetchone()
    cur.close(); conn.close()
    if not row:
        return None
    (job_name, s3_bucket, s3_key, s3_key_prefix, filename_regex, archive_prefix,
     file_format, target_table, column_mapping_json, pre_sql, post_sql, load_type) = row
    return {
        "job_name": job_name,
        "s3_bucket": s3_bucket,
        "s3_key": s3_key,
        "s3_key_prefix": s3_key_prefix,
        "filename_regex": filename_regex,
        "archive_prefix": archive_prefix,
        "file_format": file_format or "csv",
        "target_table": target_table,
        "column_mapping": json.loads(column_mapping_json) if column_mapping_json else {},
        "pre_sql": pre_sql,
        "post_sql": post_sql,
        "load_type": load_type or "append",
    }

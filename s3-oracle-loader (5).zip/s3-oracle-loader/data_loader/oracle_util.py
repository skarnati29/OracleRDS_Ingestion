import cx_Oracle
import os

def execute_sql(sql: str):
    if not sql:
        return
    conn = cx_Oracle.connect(os.getenv("ORACLE_USER"), os.getenv("ORACLE_PASS"), os.getenv("ORACLE_DSN"))
    cur = conn.cursor()
    cur.execute(sql)
    conn.commit()
    cur.close(); conn.close()

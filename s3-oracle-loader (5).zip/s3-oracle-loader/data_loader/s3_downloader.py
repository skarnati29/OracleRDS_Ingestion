import boto3
import os
import re
from datetime import datetime
from typing import Optional, Dict, Any

def _s3_client():
    return boto3.client("s3")

def find_latest_s3_key(bucket: str, prefix: str, filename_regex: Optional[str] = None, max_list: int = 1000) -> Optional[str]:
    s3 = _s3_client()
    paginator = s3.get_paginator("list_objects_v2")
    pattern = re.compile(filename_regex) if filename_regex else None
    latest_key, latest_time = None, None

    for page in paginator.paginate(Bucket=bucket, Prefix=prefix, PaginationConfig={"PageSize": max_list}):
        for obj in page.get("Contents", []):
            key = obj["Key"]
            if pattern and not pattern.search(os.path.basename(key)):
                continue
            lm = obj["LastModified"]
            if latest_time is None or lm > latest_time:
                latest_time, latest_key = lm, key
    return latest_key

def resolve_source_key(job: Dict[str, Any]) -> str:
    if job.get("s3_key"):
        return job["s3_key"]
    prefix = job.get("s3_key_prefix")
    if not prefix:
        raise ValueError("Neither s3_key nor s3_key_prefix provided in metadata.")
    key = find_latest_s3_key(job["s3_bucket"], prefix, job.get("filename_regex"))
    if not key:
        raise FileNotFoundError(f"No S3 object found under prefix '{prefix}' for bucket '{job['s3_bucket']}'.")
    return key

def download_file_from_s3(bucket: str, key: str) -> str:
    filename = os.path.basename(key)
    name, ext = os.path.splitext(filename)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    local_dir = "/tmp/data_loader"
    os.makedirs(local_dir, exist_ok=True)
    local_path = os.path.join(local_dir, f"{name}_{ts}{ext}")

    s3 = _s3_client()
    s3.download_file(bucket, key, local_path)
    return local_path

def move_s3_file_to_archive(bucket: str, source_key: str, archive_prefix: Optional[str]) -> str:
    s3 = _s3_client()
    filename = os.path.basename(source_key)
    archive_prefix = archive_prefix or "archive/"
    archive_key = f"{archive_prefix}{filename}"
    s3.copy_object(CopySource={"Bucket": bucket, "Key": source_key}, Bucket=bucket, Key=archive_key)
    s3.delete_object(Bucket=bucket, Key=source_key)
    return archive_key

import os
import subprocess
import tempfile

def run_sqlldr(data_file_path: str, table_name: str, column_mapping: dict):
    cols = ", ".join(column_mapping.values()) if column_mapping else ""
    ctl_text = f"""
    LOAD DATA
    INFILE '{data_file_path}'
    INTO TABLE {table_name}
    APPEND
    FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
    TRAILING NULLCOLS
    ({cols})
    """

    with tempfile.NamedTemporaryFile(delete=False, suffix=".ctl") as ctl:
        ctl.write(ctl_text.encode("utf-8"))
        ctl_path = ctl.name

    log_path = ctl_path.replace(".ctl", ".log")

    cmd = [
        "sqlldr",
        f"{os.getenv('ORACLE_USER')}/{os.getenv('ORACLE_PASS')}@{os.getenv('ORACLE_DSN')}",
        f"control={ctl_path}",
        f"log={log_path}"
    ]
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode != 0:
        raise RuntimeError(f"SQL*Loader failed: {result.stderr.decode(errors='ignore')}\nOutput: {result.stdout.decode(errors='ignore')}".strip())

import argparse
from data_loader.metadata_reader import get_job_from_metadata
from data_loader.loader import run_job

def main():
    parser = argparse.ArgumentParser(description="Run S3 → Oracle job by name from metadata.")
    parser.add_argument("--job-name", required=True, help="Job name from the job_metadata table")
    args = parser.parse_args()

    job = get_job_from_metadata(args.job_name)
    if not job:
        print(f"❌ Job '{args.job_name}' not found or not enabled.")
        return

    run_job(job)

if __name__ == "__main__":
    main()

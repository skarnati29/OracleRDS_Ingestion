#!/bin/bash
set -euo pipefail

if [ -f .env ]; then
  export $(grep -v '^#' .env | xargs)
fi

if [ $# -lt 1 ]; then
  echo "Usage: ./run_job.sh <job_name>"
  exit 1
fi

python3 run.py --job-name "$1"

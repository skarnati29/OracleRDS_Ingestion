CREATE TABLE job_metadata (
    job_name             VARCHAR2(100) PRIMARY KEY,
    s3_bucket            VARCHAR2(255) NOT NULL,
    s3_key               VARCHAR2(500),
    s3_key_prefix        VARCHAR2(500),
    filename_regex       VARCHAR2(200),
    archive_prefix       VARCHAR2(200),
    file_format          VARCHAR2(20) DEFAULT 'csv',
    target_table         VARCHAR2(100) NOT NULL,
    column_mapping_json  CLOB NOT NULL,
    pre_sql              CLOB,
    post_sql             CLOB,
    load_type            VARCHAR2(20) DEFAULT 'append',
    enabled              CHAR(1) DEFAULT 'Y'
);

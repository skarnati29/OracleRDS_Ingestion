INSERT INTO job_metadata (
    job_name, s3_bucket, s3_key, s3_key_prefix, filename_regex, archive_prefix,
    file_format, target_table, column_mapping_json, pre_sql, post_sql, load_type, enabled
) VALUES (
    'load_customers',
    'my-bucket',
    NULL,
    'incoming/customers_',
    'customers_\\d{8}_\\d{6}\\.csv$',
    'archive/',
    'csv',
    'customers',
    '{"customer_id": "customer_id", "name": "name", "email": "email"}',
    NULL,
    NULL,
    'append',
    'Y'
);
